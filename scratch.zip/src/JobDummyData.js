export default [
    {
        id:1,
        postedOn: '2024-03-20',
        title: 'Human Resource Manager',
        company: 'Stripe',
        type: 'Part Time',
        experience: 'Mid Level',
        location: 'Remote',
        skills: ["Recruitment Strategy", "People Management", "Interviewing Skills"],
        job_link: "https://stripe.com/jobs/search"
    
    },
    {
        id:2,
        postedOn: '2024-03-23',
        title: 'Project Manager',
        company: 'PayPal',
        type: 'Part Time',
        experience: 'Senior Level',
        location: 'Remote',
        skills: ["Project Planning", "Risk management", "Data Analysis"],
        job_link: "https://careers.pypl.com/home/"
    
    },
	
	{
        id:3,
        postedOn: '2024-03-18',
        title: 'Business Management Consultant',
        company: 'Bain & Company',
        type: 'Full Time',
        experience: 'Senior Level',
        location: 'Hybrid',
        skills: ["Supply Chain Management", "Financial Analysic", "Business Process Methodologies"],
        job_link: "https://www.bain.com/careers/"
    
    },
	
	{
        id:4,
        postedOn: '2024-04-01',
        title: 'Sales and Marketing Manager',
        company: 'Mariott International',
        type: 'Contractual',
        experience: 'Junior Level',
        location: 'In-office',
        skills: ["Digital marketing", "Customer Relationship Management", "Branding"],
        job_link: "https://careers.marriott.com/career-paths/corporate/"
    
    }

]