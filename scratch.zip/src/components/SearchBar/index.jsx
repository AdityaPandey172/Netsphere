import React from 'react'

function SearchBar() {
    return(
        <div className='flex gap-4 my-10 justify-center px-10'> 
            <select className='w-64 py-3 pl-4 bg-zinc-200 font-semibold rounded-md'>
                <option value="" diabled hidden selected>Job Role</option>
                <option value="Human Resource Manager">Human Resource Manager</option>
                <option value="Project Manager">Project Manager</option>
                <option value="Business Management Consultant">Business Management Consultant</option>
                <option value="Sales & Marketing Manager">Sales & Marketing Manager</option>
                <option value="Organizational Development Consultant">Organizational Development Consultant</option>
            </select> 
            <select className='w-64 py-3 pl-4 bg-zinc-200 font-semibold rounded-md'>
                <option value="" diabled hidden selected>Job Type</option>
                <option value="Full Time">Full Time</option>
                <option value="Part Time">Part Time</option>
                <option value="Contractual">Contractual</option>
            </select>
            <select className='w-64 py-3 pl-4 bg-zinc-200 font-semibold rounded-md'>
                <option value="" diabled hidden selected>Location</option>
                <option value="In-office">In-Office</option>
                <option value="Remote">Remote</option>
                <option value="Hybrid">Hybrid</option>
            </select>
            <select className='w-64 py-3 pl-4 bg-zinc-200 font-semibold rounded-md'>
                <option value="" diabled hidden selected>Required Experience</option>
                <option value="Fresher">Fresher</option>
                <option value="Junior Level">Junior Level</option>
                <option value="Mid Level">Mid Level</option>
                <option value="Senior Level">Senior Level</option>
            </select>
            <button className='w-64 bg-blue-500 text-white font-bold py-3 rounded-md'>Search</button>



        
        </div>
    )
}

export default SearchBar