import React from 'react'

function Header() {
  return (
    <>
      <div className='mt-10 flex flex-col gap-5 items-center justify-center text-white'>
        <hl className='text-3xl font-bold'>Expanding Horizons: Growth Opportunities within Campus and Beyond</hl>
        <p className='text-xl'>Get the Latest Posting that suit you!</p>
      </div>
      
    </>
  )
}

export default Header